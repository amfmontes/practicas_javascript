var tiempo =setInterval("popup()",6000);
function popup(){
window.alert("Se encontraron amenazas");
location.reload(true);

}
window.open("index.html");

// function falsoEnlace(){
//    location.href="paginaInvisble.html";
//    window.open("index.html")
// }
// function volver(){
//     location.href="index.html";
  
// }


